package exercicio1;

public class modelCaixa extends Thread{
    private static double saldoCentral = 0;
    String id;
    int ficha;

    public int getFicha() {s
        return ficha;
    }

    public void setFicha(int ficha) {
        this.ficha = ficha;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getsaldoCentral() {
        return saldoCentral;
    }

    public synchronized void setsaldoCentral(double saldoCentral){
        this.saldoCentral = saldoCentral;
    }

}

package exercicio1;

public class run_exe1 {
    public static void main(String[] args) {
        int ficha = 1000;

        modelCaixa caixaModel1 = new modelCaixa();
        viewCaixa caixaView1 = new viewCaixa("caixa 1", ficha);

        modelCaixa caixaModel2 = new modelCaixa();
        viewCaixa caixaView2 = new viewCaixa("caixa 2", ficha);

        modelCaixa caixaModel3 = new modelCaixa();
        viewCaixa caixaView3 = new viewCaixa("caixa 3", ficha);

        modelCaixa caixaModel4 = new modelCaixa();
        viewCaixa caixaView4 = new viewCaixa("caixa 4",ficha);

        modelCaixa caixaModel5 = new modelCaixa();
        viewCaixa caixaView5 = new viewCaixa("caixa 5",ficha);



        caixa1.vender();
        caixa2.vender();
        caixa3.vender();
        caixa4.vender();
        caixa5.vender();


    }
}

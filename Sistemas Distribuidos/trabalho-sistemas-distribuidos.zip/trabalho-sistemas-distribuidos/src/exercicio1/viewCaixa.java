package exercicio1;

public class viewCaixa {
    controllerCaixa controller = new controllerCaixa(String id, int );

    public viewCaixa(controllerCaixa controller) {
        this.controller = controller;
    }

    public void vender() {
        controller.vendaFicha();
        //System.out.println("ficha vendida! "+model.getId()+" - saldo central = "+controller.caixa.getsaldoCentral());
    }
}

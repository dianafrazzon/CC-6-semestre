package exercicio1;

public class controllerCaixa {
    modelCaixa caixa = new modelCaixa();

    public controllerCaixa(modelCaixa caixa) {
        this.caixa = caixa;
    }

    public controllerCaixa(String id, int ficha) {
        caixa.setId(id);
        caixa.setFicha(ficha);
    }

    public void vendaFicha(){
        double venda = 10;
        ficha -= ficha;
        //caixa.setFichas(caixa.getFichas()-1); //decremento o total de ficha
        caixa.setsaldoCentral(caixa.getsaldoCentral() + venda); // atualizo o saldoCentral somando o valor da venda

    }

}
